def page_view(original_function):
    def new_function(*args, **kwargs):
        original_function(*args, **kwargs)
        print("page_view invoked.")
    return new_function

def sub_view(original_function):
    def new_function(*args, **kwargs):
        original_function(*args, **kwargs)
        print("sub_view invoked.")
    return new_function

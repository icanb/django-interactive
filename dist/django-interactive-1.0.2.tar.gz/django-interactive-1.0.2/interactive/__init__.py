# Template parts
from base import (Layout)

__all__ = ('Layout')